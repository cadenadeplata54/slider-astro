import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from '../chunks/astro/server_D5PPx2XL.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from '../chunks/index_DK7SneBT.mjs';
import { H as Hero } from '../chunks/index_EJG3VxZR.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cybernetic | Homepage", "description": "Enjoy free live webcam streaming, interactive webcam videos, and live broadcasts from webcam models. No registration required, just enter and enjoy the fun." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "\u{1F1FB}\u{1F1EA} G R A C I E L A \u{1F498} \u{1F1FB}\u{1F1EA}",
      title: " ",
      background: "https://media.icfcdn.com/6d97a9/44/86772986/367b0645328d42999668369be5a69a1b/media.mp4",
      paragraph: "lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      button: {
        text: "Get pro version",
        link: "https://codexcode.store/themes/cybernetic-website-template"
      }
    },
    {
      subtitle: "Be Safe, Be Secure, Be Cybernetic",
      title: "infinite",
      background: "https://media.icfcdn.com/6d97a9/44/86772986/367b0645328d42999668369be5a69a1b/media.mp4",
      // URL del video externo,
      paragraph: "",
      button: {
        text: "Take a look",
        link: "/infinite"
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "C:/Users/usuario/Desktop/slider astro/src/pages/index.astro", void 0);

const $$file = "C:/Users/usuario/Desktop/slider astro/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
