import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from '../chunks/astro/server_D5PPx2XL.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx } from 'react/jsx-runtime';
import { M as MediaQuery, C as Container, F as FadeIn, B as Button, $ as $$Layout } from '../chunks/index_DK7SneBT.mjs';
import styled from '@emotion/styled';
import 'react';
export { renderers } from '../renderers.mjs';

const ContentSectionStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
const ContentSectionWrapper = styled.div`
    text-align: center;

    h2,
    h3,
    h4,
    h5 {
        margin-bottom: 70px;
        font-weight: 200;
    }

    figure {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;

        position: relative;

        &,
        img {
            border-radius: 10px;

            width: 100%;
            height: auto;
            object-fit: cover;
            max-width: 970px;
            margin: 0 auto;
        }
    }
`;

const ContentSection = ({
  children,
  ...rest
}) => {
  if (!children) {
    return null;
  }
  return /* @__PURE__ */ jsx(ContentSectionStyled, { ...rest, children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(ContentSectionWrapper, { children }) }) });
};

const $$404 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "404 | Page not found", "description": "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content page-404"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    height: "100%"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Wooops - Soory! 404</h1> <p>
The page you are looking for might have been removed, had
                    its name changed, or is temporarily unavailable.
</p> ${renderComponent($$result4, "Button", Button, { "variant": "secondary", "showIcon": false, "link": "/", "align": "center" }, { "default": ($$result5) => renderTemplate`
Go back
` })} ` })} ` })} </main> ` })}`;
}, "C:/Users/usuario/Desktop/slider astro/src/pages/404.astro", void 0);

const $$file = "C:/Users/usuario/Desktop/slider astro/src/pages/404.astro";
const $$url = "/404";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$404,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
